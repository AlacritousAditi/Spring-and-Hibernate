package com.example.di.service;

public interface MessageService {
    String sendMessage(String recipient, String messageBody);
}


